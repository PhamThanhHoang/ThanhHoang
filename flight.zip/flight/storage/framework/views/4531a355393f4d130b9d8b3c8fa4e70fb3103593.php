
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Flights - Worldskills Travel</title>
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('bootstrap/css/bootstrap.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(url('css/style.css')); ?>">

</head>
<body>
<div class="wrapper">
     <?php echo $__env->make('blocks.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <main>
        <div class="container">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </main>
    <?php echo $__env->make('blocks.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
<!--scripts-->
<script type="text/javascript" src="<?php echo e(url('jquery-3.2.1.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(url('bootstrap/js/bootstrap.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(url('js/loginJs.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(url('js/registerJs.js')); ?>"></script>
</body>
</html>