<?php 

foreach ($users as $key => $value) {
	echo $value['email'].' - '.$value['address'];
}

 ?>