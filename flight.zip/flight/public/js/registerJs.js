
function myBtnRegister() {
		var email = document.getElementById('email').value;
		var pass = document.getElementById('password').value;
		var name = document.getElementById('name').value;
		var phone = document.getElementById('phone').value;
		if(email == "" || pass == "" || name== "" || phone== "")
		{
			alert("Not be empty");
		}
}
function myPassword(){
		var data = document.getElementById('password').value;

	if(data.length < 8)
	{

		isPassword.innerHTML ='Please enter from 8 to 50 Characters';
		
	}
	else
	{
		isPassword.innerHTML = "";
	}
}

function myPhone() {
			var data = document.getElementById('phone').value;
			if(isNaN(data))
			{
				isPhone.innerHTML = 'Please enter number';
				
			}
			else
			{
				isPhone.innerHTML = "";
			}
}