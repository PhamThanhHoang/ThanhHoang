
                <div class="col-md-6 col-md-push-3">

                    <h2>Update your account</h2>
                    <div class="panel panel-default">
                        <div class="panel-body">
                            <?php if($i > 0 )  { ?>
                                <div><a id='isPhone' style='color: red; background: #FFFF00'>Bạn Chưa Nhập đầy đủ thông tin</a></div>
                            <?php } ?>
                            <form role="form" action="#" method="POST">
                                <?php if (isset($_SESSION['isAccount'])) {
                                    echo $_SESSION['isAccount'];
                                } ?>
                                <div class="form-group">
                                    <label class="control-label">Fullname</label>
                                    <input type="text" id="name" name="name" class="form-control" placeholder="Enter your name" value="<?php echo $getAccount[0]['fullname'] ;?>">
                                </div>
                                

                                <div class="form-group">
                                    <label class="control-label">Password:</label>
                                    <input type="password" id="password" name="password" class="form-control" placeholder="Enter your password" >
                                </div>
                                <div class="form-group">
                                    <label class="control-label">Gender:</label><br>
                                    <input type="radio" id="gender" name="gender"  value="male">Male
                                    <input type="radio" id="gender" name="gender"  value="Female">Female
                                    <input type="radio" id="gender" name="gender"  value="other">Other
                                </div>

                                <div class="form-group">
                                    <label class="control-label">Birthday:</label>
                                    <input type="date" id="birthday" name="birthday" class="form-control" value="<?php echo $getAccount[0]['birthday']?>" >
                                </div>
                                <div><a id='isPhone' style='color: red; background: #FFFF00'></a></div>

                                <div class="form-group">
                                    <label class="control-label">Address:</label>
                                    <textarea id="address" name="address" class="form-control rows="5" cols="20"><?php echo $getAccount[0]['address']; ?></textarea>
                                </div>

                                <div class="form-group">
                                    <label class="control-label">Phone Number:</label>
                                    <input type="text" id="phone" name="phone" class="form-control" placeholder="Enter your phone number" value="<?php echo $getAccount[0]['phone']?>">
                                </div>
                                <div class="text-right">
                                    <button type="submit" id="register" name="register" class="btn btn-primary">update</button>
                                </div>
                                
                            </form>
                        
                        </div>
                    </div>
                </div>
            </div>
        </div>