
@extends('layouts.app')

@section('content')
    @include('blocks.searchFlight')
@endsection

