<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/



Route::get('/',['as'=>'index', 'uses'=>'FlightController@getLogin'] );

Route::get('/index',['as'=>'index', 'uses'=>'FlightController@index']);


Route::get('/login',['as'=>'index', 'uses'=>'FlightController@getLogin']);

Route::post('/login',['as' => 'login','uses' => 'FlightController@login']);


Route::get('/test',['as'=>'index', 'uses'=>'FlightController@index']);

Route::get('/register',function(){
	return view('register');
});
Route::post('/register',['as' => 'register', 'uses' => 'FlightController@createUser']);


Route::get('/logout',['as' => 'logout', 'uses' => 'FlightController@logout']);

Route::get('/flight-list', function(){
	return View('flight-list');
});